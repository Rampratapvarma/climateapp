let cityname;
//const api_url = 'https://api.openweathermap.org/data/2.5/weather?q='+mumbai+'&appid=jbW0vINF5YUo8fiyOfubycFUJtzJWcDV';
//var response;
//var data;
async function getValue(){
cityname=document.getElementById("city").value
console.log(cityname);
const api_url = 'https://api.openweathermap.org/data/2.5/weather?q='+cityname+'&appid=641d8a6132c2f05d70e36e04bdf9f063';
document.getElementById("city").value="";
//response=await fetch(api_url);
//console.log(cityname);
//document.getElementById("weather_result").innerHTML=data;
//data = await response.json();
//console.log(data);
//document.getElementById("weather_result").innerHTML=`${cityname}</br>min tempaerature in ${cityname} is :${data["main"]["temp_min"]} F`;
const response = await fetch(api_url);
console.log(response);
if (response.status >= 200 && response.status <= 299) {
  const jsonResponse = await response.json();
  console.log(jsonResponse);
  document.getElementById("weather_result").innerHTML=`${cityname}</br>min tempaerature in ${cityname} is :${jsonResponse["main"]["temp_min"]} F`;
} else {
  // Handle errors
  console.log(response.status, response.statusText);
  document.getElementById("weather_result").innerHTML=response.status+" "+"Please enter valid city name";
}

} 